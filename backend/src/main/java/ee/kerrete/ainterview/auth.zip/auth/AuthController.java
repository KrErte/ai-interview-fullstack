package ee.krerte.aiinterview.auth;

import ee.krerte.aiinterview.auth.dto.LoginRequest;
import ee.krerte.aiinterview.auth.dto.RegisterRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<ee.krerte.aiinterview.auth.AuthResponse> register(@RequestBody RegisterRequest req) {
        ee.krerte.aiinterview.auth.AuthResponse response = authService.register(req);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<ee.krerte.aiinterview.auth.AuthResponse> login(@RequestBody LoginRequest req) {
        ee.krerte.aiinterview.auth.AuthResponse response = authService.login(req);
        return ResponseEntity.ok(response);
    }
}
