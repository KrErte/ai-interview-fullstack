package ee.krerte.aiinterview.auth;

public enum Role {
    USER,
    ADMIN
}
