package ee.krerte.aiinterview.auth;

import ee.krerte.aiinterview.auth.dto.LoginRequest;
import ee.krerte.aiinterview.auth.dto.RegisterRequest;
import ee.krerte.aiinterview.model.AppUser;
import ee.krerte.aiinterview.model.UserRole;
import ee.krerte.aiinterview.repository.AppUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public ee.krerte.aiinterview.auth.AuthResponse login(LoginRequest request) {
        AppUser user = appUserRepository.findByEmail(request.email())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String storedPassword = user.getPassword();
        String rawPassword = request.password();

        boolean matches;
        // Kui parool algab $2... siis eeldame, et see on BCrypt hash
        if (storedPassword != null && storedPassword.startsWith("$2")) {
            matches = passwordEncoder.matches(rawPassword, storedPassword);
        } else {
            // seeditud kasutajad – plain text võrdlus
            matches = storedPassword != null && storedPassword.equals(rawPassword);
        }

        if (!matches) {
            throw new RuntimeException("Wrong password");
        }

        String token = jwtService.generateToken(user.getEmail());
        return new ee.krerte.aiinterview.auth.AuthResponse(
                token,
                user.getEmail(),
                user.getFullName(),
                user.getRole().name()
        );
    }

    public void register(RegisterRequest request) {
        AppUser user = new AppUser();
        user.setEmail(request.email());
        user.setFullName(request.fullName());
        user.setRole(UserRole.USER);
        user.setCreatedAt(LocalDateTime.now());
        // uutele kasutajatele salvestame juba BCryptiga
        user.setPassword(passwordEncoder.encode(request.password()));
        appUserRepository.save(user);
    }
}
