package ee.krerte.aiinterview.model;

public enum UserRole {
    USER,
    ADMIN
}
