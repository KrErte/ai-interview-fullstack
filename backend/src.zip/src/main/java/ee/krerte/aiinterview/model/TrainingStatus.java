package ee.krerte.aiinterview.model;

public enum TrainingStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}
