package ee.krerte.aiinterview.model;

public enum UserRole {
    CANDIDATE,
    ADMIN
    // kui tahad hiljem lisada:
    // INTERVIEWER,
    // OTHER_ROLES...
}
