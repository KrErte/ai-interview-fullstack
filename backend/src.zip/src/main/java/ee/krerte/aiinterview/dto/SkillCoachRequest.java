package ee.krerte.aiinterview.dto;

import lombok.Data;

@Data
public class SkillCoachRequest {
    private String email;
    private String skillName;
}
