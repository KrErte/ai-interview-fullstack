package ee.kerrete.ainterview.dto;

import lombok.Data;

@Data
public class SkillCoachRequest {
    private String email;
    private String skillName;
}
