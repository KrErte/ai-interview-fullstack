package ee.kerrete.ainterview.model;

public enum TrainingStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}
