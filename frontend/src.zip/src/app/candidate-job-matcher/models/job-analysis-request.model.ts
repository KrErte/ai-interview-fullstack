export interface JobAnalysisRequest {
  cvText: string;
  jobDescription: string;
  email?: string;
}
