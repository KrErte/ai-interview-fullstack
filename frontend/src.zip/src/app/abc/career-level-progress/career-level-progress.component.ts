import { Component } from '@angular/core';
@Component({
  selector: 'app-career-level-progress',
  standalone: true,
  templateUrl: './career-level-progress.component.html',
  styleUrls: ['./career-level-progress.component.scss'],
})
export class CareerLevelProgressComponent {}
