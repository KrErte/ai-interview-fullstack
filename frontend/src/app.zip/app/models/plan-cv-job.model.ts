export interface PlanFromCvAndJob {
  skillGaps: string[];
  roadmap: { label: string; focus: string; details: string }[];
}
