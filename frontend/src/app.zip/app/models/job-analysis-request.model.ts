export interface JobAnalysisRequest {
  email: string;
  cvText: string;
  jobDescription: string;
}
